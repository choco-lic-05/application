import { MaxPricePipe } from './max-price.pipe';

describe('MaxPricePipe', () => {
  it('create an instance', () => {
    const pipe = new MaxPricePipe();
    expect(pipe).toBeTruthy();
  });
});
