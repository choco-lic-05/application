import { MinPricePipe } from './min-price.pipe';

describe('MinPricePipe', () => {
  it('create an instance', () => {
    const pipe = new MinPricePipe();
    expect(pipe).toBeTruthy();
  });
});
