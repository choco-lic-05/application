export class userClass{
    constructor(public email:string){}
}

export class userDetails{
    constructor(public username:string,
                public password:string){}
}